# Project resources

The compact package includes split tables under `data/`. The full project archive retains the source videos under `dataset/` and extracted images under `extracted_frames/`; restore those locally when needed. The root `.gitignore` helps prevent large media folders from being added to Git by accident. Record the original dataset source and access terms here once confirmed.
