# Installation and run guide

## Requirements

- Python with versions compatible with the pinned packages in `requirements.txt`.
- The project dependencies listed in `requirements.txt`.
- The matching source modules and dataset files required by the selected workflow.

## Create an environment

Run these commands from the project root:

```bash
python -m venv .venv
```

Activate the environment, then install the pinned dependencies:

```bash
# Windows PowerShell
.venv\Scripts\Activate.ps1

# macOS or Linux
source .venv/bin/activate

python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

## Training command

The supplied training entry point documents this command:

```bash
python src/train.py --arch resnet18
```

Optional PGD adversarial training is exposed by `--adv`; for example:

```bash
python src/train.py --arch resnet18 --adv --name resnet18_adv
```

**The supplied project archives are missing `src/model.py`, `src/dataset.py`, and `src/attacks.py`, which `src/train.py` imports. Restore the matching files before running either command.** The compact package also omits the videos, frame images, and checkpoint to stay below 25 MB. Restore those local assets from the full project archive; the split CSV files are included under `data/`.

## Comparison command

After the model evaluation and robustness steps have generated their input files, run:

```bash
python src/compare.py
```

This script expects model metric JSON files and optional robustness CSV files under `results/`. They are not part of the supplied ZIP.

## Outputs

Training code writes checkpoints under `models/` and logs/curves under `results/`. The two pre-existing figures are `results/resnet18_roc_curve.png` and `results/resnet18_confusion_matrix.png`.
