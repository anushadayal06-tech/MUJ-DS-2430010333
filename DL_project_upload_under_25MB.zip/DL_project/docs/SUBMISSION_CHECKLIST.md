# Capstone submission checklist

This checklist maps the Batch F guidelines to the supplied project snapshot.

## Personal repository

- [ ] Confirm the repository name follows `MUJ-DS-RegNo`.
- [ ] Keep the personal repository public unless instructed otherwise.
- [ ] Add the instructor as a collaborator and retain that access during training.
- [ ] Complete the `Branch` field in the root README.
- [ ] Verify name, registration number, batch, project title, GitHub username, and training program details.
- [ ] Maintain regular, meaningful commits.

## Project content

- [x] Root README added with project summary and layout.
- [x] Installation guide added under `docs/`.
- [x] Existing source scripts, split tables, and result figures included in the compact package.
- [x] Full project archive retained separately with the large media and checkpoint files.
- [ ] Restore the missing training source modules (`model.py`, `dataset.py`, and `attacks.py`) from the original project.
- [ ] Add the evaluation outputs expected by `src/compare.py` if they exist.
- [ ] Add assignment materials and notebooks if they are part of the project.
- [ ] Add presentation slides and final screenshots.
- [ ] Document the dataset source, access terms, and preprocessing when confirmed from the original project.
- [ ] Record verified experiment results and setup details; do not infer scores from filenames.

## Collaboration and capstone process

- [ ] Create and assign issues for dataset collection, model development, testing, documentation, and deployment as applicable.
- [ ] Use branches and pull requests, request reviews, and merge approved changes.
- [ ] For a separate team capstone repository, add all team members and the instructor as collaborators.
- [ ] Submit the personal repository URL, capstone repository URL, presentation, and other required materials.
