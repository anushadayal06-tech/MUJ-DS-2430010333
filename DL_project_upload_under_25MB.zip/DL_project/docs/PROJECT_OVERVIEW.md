# Project overview

## Goal

Organize the supplied deep learning capstone for frame-level deepfake detection. The repository description identifies ResNet-18 on FaceForensics++ and FGSM/PGD robustness analysis; the included training script supports selecting an architecture and enabling PGD adversarial training.

## Supplied pipeline artifacts

The full project archive contains source videos under `dataset/`, extracted images under `extracted_frames/`, split tables under `data/`, a ResNet-18 checkpoint under `models/`, two figures under `results/`, and the training and comparison scripts under `src/`. The compact package includes the scripts, split tables, figures, and documentation; it omits the large media and checkpoint files.

The intended workflow is to prepare frame-level examples and splits, train a classifier, evaluate standard and adversarial performance, and compare model outputs. The exact preprocessing and evaluation implementation cannot be fully described from this ZIP because the imported source modules are missing.

## Reproducibility status

- Dependency versions are pinned in `requirements.txt`.
- The supplied training script records loss and accuracy history and saves a best validation checkpoint.
- The supplied comparison script reads metrics and robustness files from `results/`.
- The ZIP does not include the source modules `model.py`, `dataset.py`, and `attacks.py` required by training, nor the metric and robustness files expected by comparison.
- The two existing plots are preserved as supplied; no metric values are asserted in this document.

Restore the missing project files and retain the experiment configuration, data split, and evaluation outputs with any future results so the run can be reproduced.
