# Model checkpoint

The supplied `resnet18.pth` checkpoint is 44.8 MB, so it is omitted from this compact package. It remains in the full project archive. Restore it locally when needed; use an approved large-file storage method if the checkpoint must be shared through GitHub.
