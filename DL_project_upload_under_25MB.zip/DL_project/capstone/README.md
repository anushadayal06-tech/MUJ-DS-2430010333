# Capstone materials

Keep capstone-specific supporting material here when it is separate from the project source, such as a contribution summary or final submission notes. The project code remains in its original root-level folders.
