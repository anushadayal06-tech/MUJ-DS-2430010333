# Assignments

This folder is reserved for assignment briefs and completed assignment materials related to the capstone. No assignment files were included in the supplied ZIP.
