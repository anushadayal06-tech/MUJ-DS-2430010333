# Dataset videos

Source videos are omitted from this compact package to keep it below the upload limit. They remain in the full project archive. Restore this folder locally when needed, and document the dataset source and access terms before sharing media publicly.
