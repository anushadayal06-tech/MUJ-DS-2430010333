# Results

The supplied ZIP contains:

- `resnet18_roc_curve.png`
- `resnet18_confusion_matrix.png`

Keep generated metrics, robustness tables, and plots here with the experiment configuration used to produce them. Do not infer numerical scores from image names.
