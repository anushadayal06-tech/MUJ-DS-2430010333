# Deepfake Detection with ResNet18 and Adversarial Robustness

A frame-level deepfake detection capstone using a ResNet-18 baseline, with planned comparisons across model architectures and FGSM/PGD robustness analysis. The training script also exposes optional PGD adversarial training.

> **Compact package:** This transfer package keeps the original Python scripts and result figures, adds the capstone documentation and folder structure, and includes the split CSV files. To stay below 25 MB, it leaves out the source videos, extracted frames, and the 44.8 MB checkpoint. Those assets remain in the full project archive. See [Project status](#project-status) before attempting a run.

## Student and training details

| Field | Details |
| --- | --- |
| Name | Anusha Dayal |
| Registration number | 2430010333 |
| Branch | Add your academic branch |
| Batch | F |
| Project title | Deepfake Detection with ResNet18 and Adversarial Robustness |
| GitHub username | `anushaadayal` |
| Training program | MUJ Batch F capstone (Section D, per the repository description) |

Please replace **Add your academic branch** with your official branch name before submission.

## What is included

- `src/train.py` — model training entry point, including the optional adversarial-training flag.
- `src/compare.py` — builds a cross-model comparison from metric and robustness files.
- `models/resnet18.pth` — the supplied ResNet-18 checkpoint.
- `data/splits.csv` and `data/laptop_splits.csv` — supplied dataset split tables.
- `results/` — the supplied ROC curve and confusion matrix.
- `requirements.txt` — pinned Python package versions.

The compact package omits `dataset/` media, `extracted_frames/` images, and `models/resnet18.pth` to meet the upload limit. The folder README files explain which assets to restore from the full project archive delivered separately.

## Repository layout

The original paths are kept in place so existing scripts continue to use their current locations. The folders required by the Batch F checklist are added alongside them.

```text
DL_project/
├── assignments/       # Assignment materials, if applicable
├── capstone/          # Capstone-specific supporting material
├── code/              # Index to the existing source under src/
├── data/              # Dataset split tables
├── dataset/           # Restore the source videos from the full archive
├── docs/              # Setup, project overview, and submission checklist
├── extracted_frames/  # Restore the frame images from the full archive
├── models/            # Restore the checkpoint from the full archive
├── notebooks/         # Notebook materials, if applicable
├── presentations/     # Presentation deliverables
├── resources/         # Notes about project data and assets
├── results/           # Existing result figures
├── src/               # Existing Python scripts
├── .gitignore
├── README.md
└── requirements.txt
```

## Setup

See [Installation](docs/INSTALLATION.md) for environment setup and the current source-file limitation. Dependencies are pinned in `requirements.txt`.

## Results

- [ResNet-18 ROC curve](results/resnet18_roc_curve.png)
- [ResNet-18 confusion matrix](results/resnet18_confusion_matrix.png)

These are the figures included in the supplied ZIP. No additional scores or experiment results are inferred here.

## Project status

The supplied `src/train.py` imports `model`, `dataset`, and `attacks` modules. Their Python source files are not present in either supplied archive. The full archive contains a cached `src/__pycache__/model.cpython-313.pyc`, but Python cannot reliably use that cache as a replacement for the missing source modules. Restore the matching source files from the original working repository before running training.

`src/compare.py` expects `*_metrics.json` files and may use `*_robustness.csv` files. Those inputs are not included in this package, so the comparison script needs the corresponding evaluation outputs before it can produce the comparison artifacts.

## Contribution and submission workflow

Use GitHub issues to track dataset preparation, model development, testing, documentation, and deployment. Make regular commits on focused branches, open pull requests for review, and keep the instructor as a collaborator as required by the course. Keep the personal repository public unless the course staff says otherwise.

Before final submission, include the completed student details, source code, project documentation, installation guide, presentation, screenshots, and results. The [submission checklist](docs/SUBMISSION_CHECKLIST.md) records the remaining items for this ZIP snapshot.
