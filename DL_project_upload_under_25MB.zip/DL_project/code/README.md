# Source code index

The original Python entry points remain under `src/` so their current paths are preserved. The supplied ZIP includes `src/train.py` and `src/compare.py`; restore the imported source modules noted in the root README before running the training workflow.
