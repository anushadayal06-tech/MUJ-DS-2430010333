# Extracted frames

Frame images are omitted from this compact package to keep it below the upload limit. They remain in the full project archive. Restore this folder locally when needed.
